package Mojolicious::Plugin::RoutesAuthDBI::Model::Base;
use Mojo::Base 'DBIx::Mojo::Model';

#~ sub new {
  #~ $self = shift->SUPER::new(@_);
#~ }

1;
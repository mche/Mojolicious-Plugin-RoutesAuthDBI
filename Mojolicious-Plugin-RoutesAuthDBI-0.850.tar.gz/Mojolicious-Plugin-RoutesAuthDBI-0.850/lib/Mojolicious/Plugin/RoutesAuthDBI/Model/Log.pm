package Mojolicious::Plugin::RoutesAuthDBI::Model::Log;
#~ use Mojo::Base 'DBIx::Mojo::Model';
use Mojo::Base 'Mojolicious::Plugin::RoutesAuthDBI::Model::Base';


#~ sub new {
  #~ my $self = shift->SUPER::new(@_);
  
  
#~ }

1;

__DATA__
@@ ---
---

